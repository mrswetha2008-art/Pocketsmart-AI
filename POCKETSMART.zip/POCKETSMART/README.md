# PocketSmart

A simple executable Flask web application with:
- User registration/login
- SQLite database
- Dashboard
- Home Planner
- Jewelry Planner
- Party Planner
- Image uploads
- Plan history
- Delete plan
- JSON API for saved plans

## 1. Open in VS Code

Open the `POCKETSMART` folder.

## 2. Create virtual environment

Windows:

    python -m venv venv
    venv\Scripts\activate

## 3. Install dependencies

    pip install -r requirements.txt

## 4. Run

    python app.py

## 5. Open in browser

    http://127.0.0.1:5000

The SQLite database `pocketsmart.db` is created automatically on first run.

## Notes

Do not upload `venv`, `__pycache__`, or `.env` to a public repository.
Change `SECRET_KEY` in `.env` before deploying.
