import os
import sqlite3
from datetime import datetime
from pathlib import Path
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

UPLOAD_FOLDER = BASE_DIR / "static" / "uploads"
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)

DB_PATH = BASE_DIR / "pocketsmart.db"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            plan_type TEXT NOT NULL,
            title TEXT NOT NULL,
            details TEXT NOT NULL,
            image TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
    """)
    conn.commit()
    conn.close()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.context_processor
def inject_user():
    return {"current_user": session.get("user_name")}


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("register.html")

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "danger")
            return render_template("register.html")

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(name,email,password,created_at) VALUES(?,?,?,?)",
                (name, email, generate_password_hash(password),
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            )
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash("An account with this email already exists.", "danger")
            return render_template("register.html")

        conn.close()
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email = ?", (email,)
        ).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            session["user_email"] = user["email"]
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    plans = conn.execute(
        "SELECT * FROM plans WHERE user_id = ? ORDER BY id DESC LIMIT 6",
        (session["user_id"],)
    ).fetchall()
    total = conn.execute(
        "SELECT COUNT(*) AS count FROM plans WHERE user_id = ?",
        (session["user_id"],)
    ).fetchone()["count"]
    conn.close()
    return render_template("dashboard.html", plans=plans, total=total)


def create_plan(plan_type, template_name, title_label):
    if request.method == "GET":
        return render_template(template_name)

    title = request.form.get("title", "").strip()
    details = request.form.get("details", "").strip()
    image = request.files.get("image")

    if not title or not details:
        flash("Please enter both title and details.", "danger")
        return render_template(template_name)

    filename = None
    if image and image.filename:
        if not allowed_file(image.filename):
            flash("Unsupported image format.", "danger")
            return render_template(template_name)

        safe_name = secure_filename(image.filename)
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
        filename = f"{timestamp}_{safe_name}"
        image.save(UPLOAD_FOLDER / filename)

    conn = get_db()
    conn.execute(
        """INSERT INTO plans(user_id,plan_type,title,details,image,created_at)
           VALUES(?,?,?,?,?,?)""",
        (
            session["user_id"],
            plan_type,
            title,
            details,
            filename,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    )
    conn.commit()
    conn.close()

    flash(f"{title_label} saved successfully.", "success")
    return redirect(url_for("history"))


@app.route("/home-planner", methods=["GET", "POST"])
@login_required
def home_planner():
    return create_plan("Home Planner", "home_planner.html", "Home plan")


@app.route("/jewelry-planner", methods=["GET", "POST"])
@login_required
def jewelry_planner():
    return create_plan("Jewelry Planner", "jewelry_planner.html", "Jewelry plan")


@app.route("/party-planner", methods=["GET", "POST"])
@login_required
def party_planner():
    return create_plan("Party Planner", "party_planner.html", "Party plan")


@app.route("/history")
@login_required
def history():
    conn = get_db()
    plans = conn.execute(
        "SELECT * FROM plans WHERE user_id = ? ORDER BY id DESC",
        (session["user_id"],)
    ).fetchall()
    conn.close()
    return render_template("history.html", plans=plans)


@app.route("/delete-plan/<int:plan_id>", methods=["POST"])
@login_required
def delete_plan(plan_id):
    conn = get_db()
    plan = conn.execute(
        "SELECT * FROM plans WHERE id = ? AND user_id = ?",
        (plan_id, session["user_id"])
    ).fetchone()

    if plan:
        if plan["image"]:
            image_path = UPLOAD_FOLDER / plan["image"]
            if image_path.exists():
                image_path.unlink()
        conn.execute(
            "DELETE FROM plans WHERE id = ? AND user_id = ?",
            (plan_id, session["user_id"])
        )
        conn.commit()
        flash("Plan deleted.", "success")

    conn.close()
    return redirect(url_for("history"))


@app.route("/api/plans")
@login_required
def api_plans():
    conn = get_db()
    rows = conn.execute(
        """SELECT id, plan_type, title, details, image, created_at
           FROM plans WHERE user_id = ? ORDER BY id DESC""",
        (session["user_id"],)
    ).fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])


@app.errorhandler(413)
def too_large(_error):
    flash("The uploaded file is too large. Maximum size is 8 MB.", "danger")
    return redirect(request.referrer or url_for("dashboard"))


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", 5000)), debug=True)
